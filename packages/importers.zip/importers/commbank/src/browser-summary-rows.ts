import type {
  ParsedStatement,
  ParsedStatementBalance,
  ParsedStatementMetadata,
  ParsedStatementReconciliation,
  ParsedStatementRow,
  ReconciliationStatus,
} from "@aqchafold/importers-core";
import type { TextItem } from "pdfjs-serverless";

const months = [
  "jan",
  "feb",
  "mar",
  "apr",
  "may",
  "jun",
  "jul",
  "aug",
  "sep",
  "oct",
  "nov",
  "dec",
];
const normalized = (text: string) =>
  text.replace(/\s+/g, " ").trim().toLowerCase();

function tableColumns(items: readonly TextItem[]): TextItem[] | undefined {
  for (const date of items.filter((item) => normalized(item.str) === "date")) {
    const columns = [date];
    for (const name of ["transaction", "debit", "credit", "balance"]) {
      const column = items.find(
        (item) =>
          normalized(item.str) === name &&
          item.transform[4] > columns[columns.length - 1].transform[4] &&
          Math.abs(item.transform[5] - date.transform[5]) <= 2,
      );
      if (!column) break;
      columns.push(column);
    }
    if (columns.length === 5) return columns;
  }
}

function lines(items: readonly TextItem[]): { y: number; items: TextItem[] }[] {
  const result: { y: number; items: TextItem[] }[] = [];
  for (const item of [...items].sort(
    (a, b) => b.transform[5] - a.transform[5],
  )) {
    const last = result[result.length - 1];
    if (last && Math.abs(last.y - item.transform[5]) <= 2)
      last.items.push(item);
    else result.push({ y: item.transform[5], items: [item] });
  }
  for (const line of result)
    line.items.sort((a, b) => a.transform[4] - b.transform[4]);
  return result;
}

function calendarDate(raw: string, year: number): string | undefined {
  const match = /^(\d{2})\s+([a-z]{3})$/i.exec(raw.trim());
  if (!match || year < 1 || year > 9999) return;
  const day = Number(match[1]);
  const month = months.indexOf(match[2].toLowerCase()) + 1;
  if (!month) return;
  const leap = year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0);
  const length = [31, leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][
    month - 1
  ];
  if (day < 1 || day > length) return;
  return `${String(year).padStart(4, "0")}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
}

/** Validate interpreted dates using the same Gregorian rules as source dates. */
export function isGregorianCalendarDate(value: unknown): value is string {
  if (typeof value !== "string") return false;
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
  if (!match) return false;
  const month = months[Number(match[2]) - 1];
  return (
    month !== undefined &&
    calendarDate(`${match[3]} ${month}`, Number(match[1])) === value
  );
}

type DateContext = { year: number; start: string; end: string };

function description(
  sourceLines: readonly (readonly TextItem[])[],
): Pick<ParsedStatementRow, "rawDescription" | "warnings"> {
  if (!sourceLines.length)
    return {
      warnings: [
        "No source transaction description was established for this movement.",
      ],
    };
  let duplicated = false;
  let ambiguous = false;
  const text = sourceLines.map((items) => {
    const runs: TextItem[] = [];
    for (const item of items) {
      if (
        runs.some(
          (run) =>
            run.str === item.str &&
            Math.abs(run.transform[4] - item.transform[4]) <= 2,
        )
      ) {
        duplicated = true;
        continue;
      }
      if (
        runs.some(
          (run) =>
            Math.min(
              run.transform[4] + run.width,
              item.transform[4] + item.width,
            ) -
              Math.max(run.transform[4], item.transform[4]) >
            2,
        )
      )
        ambiguous = true;
      runs.push(item);
    }
    return runs.map((run) => run.str).join(" ");
  });
  if (ambiguous)
    return {
      warnings: [
        "Overlapping Transaction-column text makes the source description ambiguous.",
      ],
    };
  return {
    rawDescription: text.join("\n"),
    warnings: duplicated
      ? [
          "Identical overlapping Transaction-column text runs were collapsed for the description.",
        ]
      : [],
  };
}

/** Internal two-decimal magnitude parser; converts integer digits, never decimal floats. */
export function parseDecimalMagnitudeMinor(raw: string): number | undefined {
  const match = /^(?:\d+|\d{1,3}(?:,\d{3})+)\.\d{2}$/.exec(raw);
  // JavaScript's $ anchor can match before a final line terminator.
  if (match?.[0] !== raw) return;
  const minor = Number(raw.replace(/[,.]/g, ""));
  return Number.isSafeInteger(minor) ? minor : undefined;
}

/** Both source cells must be established, with exactly one valid magnitude. */
export function parseSignedDebitCreditMinor(
  rawDebit: string | undefined,
  rawCredit: string | undefined,
): number | undefined {
  if (typeof rawDebit !== "string" || typeof rawCredit !== "string") return;
  if (rawDebit === "" && rawCredit !== "")
    return parseDecimalMagnitudeMinor(rawCredit);
  if (rawCredit === "" && rawDebit !== "") {
    const magnitude = parseDecimalMagnitudeMinor(rawDebit);
    return magnitude === undefined ? undefined : -magnitude;
  }
}

function amountCells(
  items: readonly TextItem[],
  debit: TextItem,
  credit: TextItem,
): Pick<ParsedStatementRow, "rawDebit" | "rawCredit" | "warnings"> & {
  signedMinor?: number;
} {
  const boundary = (debit.transform[4] + debit.width + credit.transform[4]) / 2;
  const creditRight = credit.transform[4] + credit.width;
  const creditItems = items.filter(
    (item) =>
      item.transform[4] >= boundary ||
      Math.abs(item.transform[4] + item.width - creditRight) <= 2,
  );
  const warnings: string[] = [];
  const sourceCell = (runs: readonly TextItem[], name: string) => {
    const unique = runs.filter(
      (item, index) =>
        !runs
          .slice(0, index)
          .some(
            (other) =>
              other.str === item.str &&
              Math.abs(other.transform[4] - item.transform[4]) <= 2,
          ),
    );
    const raw = unique.map((item) => item.str).join(" ");
    const minor =
      unique.length === 1 ? parseDecimalMagnitudeMinor(raw) : undefined;
    if (unique.length < runs.length)
      warnings.push(`Identical overlapping ${name} text runs were collapsed.`);
    if (unique.length > 1)
      warnings.push(
        `The ${name} cell has multiple text runs; its magnitude is ambiguous.`,
      );
    else if (raw && minor === undefined)
      warnings.push(
        `The ${name} cell is not a valid safe two-decimal magnitude.`,
      );
    return { raw, minor };
  };
  const debitCell = sourceCell(
    items.filter((item) => !creditItems.includes(item)),
    "Debit",
  );
  const creditCell = sourceCell(creditItems, "Credit");
  const rawDebit = debitCell.raw;
  const rawCredit = creditCell.raw;
  if (Boolean(rawDebit) === Boolean(rawCredit))
    warnings.push(
      "Exactly one Debit or Credit cell must be populated for a movement.",
    );
  const signedMinor = parseSignedDebitCreditMinor(rawDebit, rawCredit);
  return { rawDebit, rawCredit, warnings, signedMinor };
}

function balanceRuns(
  items: readonly TextItem[],
  y: number,
  left: number,
  right = Infinity,
): TextItem[] {
  return items
    .filter(
      (item) =>
        item.str.length > 0 &&
        (item.str.trim() || item.height > 0) &&
        Math.abs(item.transform[5] - y) <= 2 &&
        item.transform[4] >= left &&
        item.transform[4] <= right,
    )
    .sort((a, b) => a.transform[4] - b.transform[4]);
}

function balanceCell(items: readonly TextItem[], name: string) {
  const warnings: string[] = [];
  const unique = items.filter(
    (item, index) =>
      !items
        .slice(0, index)
        .some(
          (other) =>
            other.str === item.str &&
            Math.abs(other.transform[4] - item.transform[4]) <= 2 &&
            Math.abs(other.transform[5] - item.transform[5]) <= 2,
        ),
  );
  const rawValue = unique.length
    ? unique.map((item) => item.str).join(" ")
    : undefined;
  const minor =
    unique.length === 1 && rawValue?.startsWith("$")
      ? parseDecimalMagnitudeMinor(rawValue.slice(1))
      : undefined;
  if (unique.length < items.length)
    warnings.push(`Identical overlapping ${name} text runs were collapsed.`);
  if (!unique.length) warnings.push(`The ${name} value is missing.`);
  else if (unique.length > 1)
    warnings.push(
      `The ${name} has multiple text runs; its value is ambiguous.`,
    );
  else if (minor === undefined)
    warnings.push(
      `The ${name} is not valid dollar-prefixed two-decimal notation.`,
    );
  return { rawValue, warnings, minor };
}

function dateContext(
  items: readonly TextItem[],
  openingYears: readonly number[],
): DateContext | undefined {
  const periods = new Set(
    items
      .filter((item) => normalized(item.str) === "period")
      .map((label) =>
        items
          .filter(
            (item) =>
              item.transform[4] > label.transform[4] + label.width &&
              Math.abs(item.transform[5] - label.transform[5]) <= 2,
          )
          .sort((a, b) => a.transform[4] - b.transform[4])
          .map((item) => item.str)
          .join(" "),
      ),
  );
  if (periods.size !== 1 || new Set(openingYears).size !== 1) return;
  const period =
    /^(\d{2}\s+[a-z]{3})\s+-\s+(\d{2}\s+[a-z]{3})\s+(\d{4})$/i.exec(
      [...periods][0].trim(),
    );
  if (!period) return;
  const year = Number(period[3]);
  if (year !== openingYears[0]) return;
  const start = calendarDate(period[1], year);
  const end = calendarDate(period[2], year);
  // No rollover is inferred from row order or from a period with an omitted year.
  if (!start || !end || start > end) return;
  return { year, start, end };
}

function statementMetadata(
  items: readonly TextItem[],
  openingYears: readonly number[],
): Pick<ParsedStatement, "metadata" | "warnings"> {
  const warnings: string[] = [];
  const table = tableColumns(items);
  const header = items.filter(
    (item) =>
      table &&
      item.transform[5] > table[0].transform[5] &&
      item.str.length > 0 &&
      (item.str.trim() || item.height > 0),
  );
  const labels = ["account number", "statement", "period", "closing balance"];
  const bankName = "commonwealth bank of australia";
  const rawText = lines(header)
    .filter((line) =>
      line.items.some((item) => {
        const text = normalized(item.str);
        return (
          labels.includes(text) ||
          text === bankName ||
          text === "commonwealth bank" ||
          text === "transaction summary" ||
          /^\(page \d+ of \d+\)$/.test(text)
        );
      }),
    )
    .map((line) => line.items.map((item) => item.str).join(" "))
    .join("\n");
  // This view belongs to metadata only; row and balance source handling is unchanged.
  const unique = header.filter(
    (item, index) =>
      !header
        .slice(0, index)
        .some(
          (other) =>
            other.str === item.str &&
            Math.abs(other.transform[4] - item.transform[4]) <= 2 &&
            Math.abs(other.transform[5] - item.transform[5]) <= 2,
        ),
  );
  if (unique.length < header.length)
    warnings.push(
      "Identical overlapping header text runs were collapsed for metadata fields; raw header evidence is retained.",
    );
  const institutions = new Set(
    unique
      .filter((item) => normalized(item.str) === bankName)
      .map((item) => item.str),
  );
  let institution: string | undefined;
  if (institutions.size === 1) institution = [...institutions][0];
  else
    warnings.push(
      "The full institution name is missing or ambiguous in the header.",
    );

  function field(name: string) {
    const cells = unique
      .filter((item) => normalized(item.str) === name.toLowerCase())
      .map((label) => {
        const runs = unique
          .filter(
            (item) =>
              item.transform[4] > label.transform[4] + label.width &&
              Math.abs(item.transform[5] - label.transform[5]) <= 2,
          )
          .sort((a, b) => a.transform[4] - b.transform[4]);
        return {
          text: runs.map((item) => item.str).join(" "),
          overlapping: runs.some((item, index) =>
            runs
              .slice(0, index)
              .some(
                (other) =>
                  other.transform[4] + other.width - item.transform[4] > 2,
              ),
          ),
        };
      });
    if (!cells.length || cells.some((cell) => !cell.text.trim())) {
      warnings.push(`The header ${name} value is missing.`);
      return;
    }
    if (
      cells.some((cell) => cell.overlapping) ||
      new Set(cells.map((cell) => cell.text)).size !== 1
    ) {
      warnings.push(
        `The header ${name} evidence is ambiguous; no value was selected.`,
      );
      return;
    }
    const raw = cells[0].text;
    if (
      [...raw].some(
        (char) => char.charCodeAt(0) < 32 || char.charCodeAt(0) === 127,
      )
    ) {
      warnings.push(
        `The header ${name} source value contains malformed control text.`,
      );
      return;
    }
    return raw;
  }

  const accountIdentifier = field("Account Number");
  const period = field("Period");
  const context =
    period === undefined ? undefined : dateContext(unique, openingYears);
  if (period !== undefined && !context)
    warnings.push(
      "The header Period does not establish a valid same-year Gregorian range with the opening-balance year.",
    );
  const metadata: ParsedStatementMetadata = {
    rawText,
    ...(institution === undefined ? {} : { institution }),
    ...(accountIdentifier === undefined ? {} : { accountIdentifier }),
    ...(context ? { periodStart: context.start, periodEnd: context.end } : {}),
  };
  return { metadata, warnings };
}

/** Bank-specific source rows; Money remains unresolved until currency is established. */
export function parseBrowserSummaryRows(
  pages: readonly (readonly TextItem[])[],
): Pick<
  ParsedStatement,
  | "metadata"
  | "rows"
  | "warnings"
  | "openingBalance"
  | "closingBalance"
  | "reconciliation"
> {
  const warnings: string[] = [];
  const openingYears: number[] = [];
  const openingEntries: {
    rawText: string;
    dates: string[];
    ambiguousLabel: boolean;
    precedingMovements: number;
    position: { page: number; row: number };
    cell: ReturnType<typeof balanceCell>;
  }[] = [];
  const records: {
    page: number;
    dates: string[];
    rawText: string;
    description: Pick<ParsedStatementRow, "rawDescription" | "warnings">;
    amounts: ReturnType<typeof amountCells>;
    balance: ReturnType<typeof balanceCell>;
    previousBalanceKnown: boolean;
  }[] = [];
  let sourceGap = false;
  const sourcePages = pages.map((items) => {
    const seen = new Set<string>();
    return items.filter((item) => {
      if (!item.str.trim()) return false;
      const key = JSON.stringify([
        item.transform[4],
        item.transform[5],
        item.str,
      ]);
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  });
  if (
    sourcePages.some(
      (items, index) =>
        items.length < pages[index].filter((item) => item.str.trim()).length,
    )
  ) {
    warnings.push(
      "Identical overlapping PDF text runs were collapsed for source row extraction.",
    );
  }

  for (const [index, items] of sourcePages.entries()) {
    const columns = tableColumns(items);
    if (!columns) {
      sourceGap = true;
      warnings.push(
        `Page ${index + 1} has no supported transaction table; date coverage is partial.`,
      );
      continue;
    }
    const [date, transaction, debit, credit, balance] = columns;
    const body = items.filter(
      (item) =>
        item.transform[5] < date.transform[5] - 2 &&
        item.transform[4] >= date.transform[4] - 2,
    );
    const movementLeft =
      (transaction.transform[4] + transaction.width + debit.transform[4]) / 2;
    const movementRight =
      (credit.transform[4] + credit.width + balance.transform[4]) / 2;
    let dates: string[] = [];
    let text: string[] = [];
    let descriptionLines: TextItem[][] = [];
    let tableRow = 0;
    for (const line of lines(body)) {
      const openingLabels = line.items.filter(
        (item) =>
          item.transform[4] >= transaction.transform[4] - 2 &&
          item.transform[4] < movementLeft &&
          /^(?:\d{4}\s+)?opening balance$/i.test(item.str.trim()),
      );
      const opening = openingLabels[0];
      if (opening) {
        const year = /^(\d{4})\s+/i.exec(opening.str.trim());
        if (year) openingYears.push(Number(year[1]));
        openingEntries.push({
          rawText: line.items.map((item) => item.str).join(" "),
          precedingMovements: records.length,
          ambiguousLabel:
            new Set(openingLabels.map((item) => normalized(item.str))).size > 1,
          dates: [
            ...new Set(
              line.items
                .filter(
                  (item) => item.transform[4] < transaction.transform[4] - 2,
                )
                .map((item) => item.str),
            ),
          ],
          position: { page: index + 1, row: ++tableRow },
          cell: balanceCell(
            balanceRuns(
              pages[index],
              line.y,
              movementRight,
              balance.transform[4] + balance.width + 2,
            ),
            "opening balance",
          ),
        });
        dates = [];
        text = [];
        descriptionLines = [];
        continue;
      }
      const sourceDates = line.items
        .filter((item) => item.transform[4] < transaction.transform[4] - 2)
        .map((item) => item.str);
      if (sourceDates.length) {
        dates = [...new Set(sourceDates)];
        text = [];
        descriptionLines = [];
      }
      text.push(line.items.map((item) => item.str).join(" "));
      const descriptionItems = line.items.filter(
        (item) =>
          item.transform[4] >= transaction.transform[4] - 2 &&
          item.transform[4] < movementLeft,
      );
      if (descriptionItems.length) descriptionLines.push(descriptionItems);
      // The demonstrated layout places financial cells on the final description line.
      const movementItems = line.items.filter(
        (item) =>
          item.transform[4] >= movementLeft &&
          item.transform[4] < movementRight,
      );
      // Preserve real whitespace-only cell runs without adding PDF.js gap spacers
      // (height 0), or changing the existing rawText/date/description observations.
      movementItems.push(
        ...pages[index].filter(
          (item) =>
            item.str.length > 0 &&
            !item.str.trim() &&
            item.height > 0 &&
            Math.abs(item.transform[5] - line.y) <= 2 &&
            item.transform[4] >= movementLeft &&
            item.transform[4] < movementRight,
        ),
      );
      movementItems.sort((a, b) => a.transform[4] - b.transform[4]);
      // Balance-column presence retains missing-amount rows without interpreting balances.
      const hasBalanceCell =
        (dates.length > 0 || descriptionLines.length > 0) &&
        line.items.some(
          (item) =>
            item.transform[4] >= movementRight &&
            item.transform[4] <= balance.transform[4] + balance.width + 2,
        );
      if (!movementItems.length && !hasBalanceCell) continue;
      tableRow++;
      records.push({
        page: index + 1,
        previousBalanceKnown: !sourceGap,
        dates,
        rawText: text.join("\n"),
        description: description(descriptionLines),
        amounts: amountCells(movementItems, debit, credit),
        balance: balanceCell(
          balanceRuns(
            pages[index],
            line.y,
            movementRight,
            balance.transform[4] + balance.width + 2,
          ),
          "running balance",
        ),
      });
      sourceGap = false;
      dates = [];
      text = [];
      descriptionLines = [];
    }
  }
  const context = dateContext(sourcePages[0], openingYears);
  if (!context)
    warnings.push(
      "The Period and opening-balance year do not establish an unambiguous same-year date range.",
    );
  let openingBalance: ParsedStatementBalance | undefined;
  for (const entry of openingEntries) warnings.push(...entry.cell.warnings);
  if (!openingEntries.length)
    warnings.push("No explicit opening-balance entry was established.");
  else {
    const rawDate = openingEntries
      .map((entry) => entry.dates.join(" "))
      .join("\n");
    openingBalance = {
      rawText: openingEntries.map((entry) => entry.rawText).join("\n"),
      rawValue: openingEntries
        .map((entry) => entry.cell.rawValue ?? "")
        .join("\n"),
      ...(rawDate ? { rawDate } : {}),
      ...(openingEntries.length === 1
        ? { position: openingEntries[0].position }
        : {}),
    };
    if (openingEntries.length !== 1)
      warnings.push(
        "Multiple opening-balance entries are ambiguous; no entry was selected.",
      );
    else if (openingEntries[0].ambiguousLabel)
      warnings.push(
        "Conflicting opening-balance labels make its date ambiguous; no date was selected.",
      );
    else {
      const entry = openingEntries[0];
      const date =
        context && entry.dates.length === 1
          ? calendarDate(entry.dates[0], context.year)
          : undefined;
      if (date && context && date >= context.start && date <= context.end)
        openingBalance = { ...openingBalance, date };
      else
        warnings.push(
          "The opening-balance date is unresolved from the established date context.",
        );
    }
  }
  const closingEntries: {
    rawText: string;
    cell: ReturnType<typeof balanceCell>;
  }[] = [];
  const firstTable = tableColumns(sourcePages[0] ?? []);
  for (const line of lines(sourcePages[0] ?? [])) {
    if (!firstTable || line.y <= firstTable[0].transform[5]) continue;
    const labels = line.items.filter(
      (item) => normalized(item.str) === "closing balance",
    );
    if (!labels.length) continue;
    const left = Math.min(...labels.map((item) => item.transform[4]));
    const right = Math.min(
      ...labels.map((item) => item.transform[4] + item.width),
    );
    closingEntries.push({
      rawText: line.items
        .filter((item) => item.transform[4] >= left - 2)
        .map((item) => item.str)
        .join(" "),
      cell: balanceCell(
        balanceRuns(pages[0], line.y, right),
        "header closing balance",
      ),
    });
  }
  let closingBalance: ParsedStatementBalance | undefined;
  for (const entry of closingEntries) warnings.push(...entry.cell.warnings);
  if (!closingEntries.length)
    warnings.push("No header closing-balance evidence was established.");
  else {
    closingBalance = {
      rawText: closingEntries.map((entry) => entry.rawText).join("\n"),
      rawValue: closingEntries
        .map((entry) => entry.cell.rawValue ?? "")
        .join("\n"),
    };
    if (closingEntries.length !== 1)
      warnings.push(
        "Multiple header closing-balance entries are ambiguous; no entry was selected.",
      );
  }
  const rows: ParsedStatementRow[] = records.map((record, index) => {
    const rawPostingDate = record.dates.length
      ? record.dates.join(" ")
      : undefined;
    const rowWarnings: string[] = [
      ...record.description.warnings,
      ...record.amounts.warnings,
      ...record.balance.warnings,
    ];
    let postingDate: string | undefined;
    if (rawPostingDate === undefined)
      rowWarnings.push(
        "No source posting date was established for this movement.",
      );
    else if (record.dates.length !== 1)
      rowWarnings.push(
        "The Date cell has multiple text runs; its posting date is ambiguous.",
      );
    else if (!context)
      rowWarnings.push(
        "Posting date year is unresolved from statement context.",
      );
    else {
      const interpreted = calendarDate(rawPostingDate, context.year);
      if (!interpreted)
        rowWarnings.push(
          "The source posting date is not a valid DD Mon Gregorian date.",
        );
      else if (interpreted < context.start || interpreted > context.end)
        rowWarnings.push(
          "The source posting date is outside the evidenced statement period.",
        );
      else postingDate = interpreted;
    }
    return {
      position: { page: record.page, row: index + 1 },
      rawText: record.rawText,
      rawDebit: record.amounts.rawDebit,
      rawCredit: record.amounts.rawCredit,
      ...(record.balance.rawValue === undefined
        ? {}
        : { rawBalance: record.balance.rawValue }),
      ...(record.description.rawDescription === undefined
        ? {}
        : { rawDescription: record.description.rawDescription }),
      ...(rawPostingDate === undefined ? {} : { rawPostingDate }),
      ...(postingDate === undefined ? {} : { postingDate }),
      warnings: rowWarnings,
    };
  });
  const metadata = statementMetadata(pages[0] ?? [], openingYears);
  const openingMinor =
    openingEntries.length === 1 &&
    !openingEntries[0].ambiguousLabel &&
    openingEntries[0].precedingMovements === 0
      ? openingEntries[0].cell.minor
      : undefined;
  const checks = rows.map(({ position }, index) => {
    const previous = !records[index].previousBalanceKnown
      ? undefined
      : index === 0
        ? openingMinor
        : records[index - 1].balance.minor;
    const movement = records[index].amounts.signedMinor;
    const current = records[index].balance.minor;
    let status: ReconciliationStatus;
    let reason: string | undefined;
    if (
      previous === undefined ||
      movement === undefined ||
      current === undefined
    ) {
      status = "unresolved";
      const missing = [
        ...(previous === undefined ? ["previous source balance"] : []),
        ...(movement === undefined ? ["signed Debit/Credit movement"] : []),
        ...(current === undefined ? ["current source running balance"] : []),
      ];
      reason = `Valid unambiguous evidence is unavailable for ${missing.join(", ")}.`;
    } else if (movement > 0 && previous > Number.MAX_SAFE_INTEGER - movement) {
      status = "unresolved";
      reason = "The integer sum is outside the safe range.";
    } else {
      status = previous + movement === current ? "verified" : "mismatch";
      if (status === "mismatch")
        reason =
          "Previous source balance plus signed movement differs from current source balance.";
    }
    if (reason)
      warnings.push(
        `Running balance reconciliation ${status} at page ${position.page}, row ${position.row}: ${reason}`,
      );
    return { position, status };
  });
  const finalMinor = sourceGap
    ? undefined
    : records[records.length - 1]?.balance.minor;
  const closingMinor =
    closingEntries.length === 1 ? closingEntries[0].cell.minor : undefined;
  const closingStatus: ReconciliationStatus =
    finalMinor === undefined || closingMinor === undefined
      ? "unresolved"
      : finalMinor === closingMinor
        ? "verified"
        : "mismatch";
  if (closingStatus !== "verified")
    warnings.push(
      closingStatus === "mismatch"
        ? "Closing balance reconciliation mismatch: header closing balance differs from final source running balance."
        : "Closing balance reconciliation unresolved: valid unambiguous header closing and final source running balances are required.",
    );
  const reconciliation: ParsedStatementReconciliation = {
    rows: checks,
    closingBalance: closingStatus,
  };
  return {
    metadata: metadata.metadata,
    rows,
    reconciliation,
    warnings: [...warnings, ...metadata.warnings],
    ...(openingBalance ? { openingBalance } : {}),
    ...(closingBalance ? { closingBalance } : {}),
  };
}
